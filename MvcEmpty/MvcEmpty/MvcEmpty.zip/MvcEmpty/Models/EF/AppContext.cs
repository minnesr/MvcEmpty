﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using MvcEmpty.Models.Users;
using MvcEmpty.Models.Orders;

namespace MvcEmpty.Models.EF
{
    public class AppContext :DbContext
    {
        public AppContext()
            : base("DefaultConnection") 
        {
            Database.SetInitializer<AppContext>(new DropCreateDatabaseIfModelChanges<AppContext>());

        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }

    }
}